var express = require("express");
var app = express();
var server = app.listen(3026);
var io = require("socket.io").listen(server);

//        ****************************
// THIS IS HOME PAGE WHEN CLIENT PING THE SERVER 
app.get("/",function(req,res,err){
	res.sendFile(__dirname+"/index.html");
});
//        ****************************

var sockets = [];  // STORE ALL THE CLIENTS THOSE ARE ACTIVE 
var users = [];    // STORE ALL THE USERS THOSE ARE ACTIVE 
var sockets_with_name = [];  // STORE ALL THE CLIENTS AND USERS 


io.on("connection",function(client){
	
	 
	 client.on('disconnect', function(){
	 	  //  THIS LINE IS USE FOR REMOVE THE USER WHEN USER WILL GOING OFFLINE
	 	   users.splice(sockets.indexOf(client),1);
	 	  //                         ************************
	 });
	 //                         ************************
	 //   THIS IS USE WHEN USER CLICK THE SUBMIT BUTTON IN CLIENT SIDE SCRIPT 

	 client.on('send msg',function(data){
	 	  // THIS VARIABLE USE FOR STORE THE MESSAGE WITH COLOR 
	 	  var mg="";
          // ONLY FIRST CLIENTS HAVE RED COLOR AND THEN AFTER  ALL THE CLIENTS HAVE GREEN COLOR  
	 	  if(sockets[0].conn.id == client.conn.id )
	 	  		mg ="<div style='color:red' >"+data.msg+"</div>";
	 	  else	
	 	       mg ="<div style='color:green' >"+data.msg+"</div>";	
	 	 
	 	    //                     **************************
	 	    //        this commented line is use for send the msg to all clients 
	 	    //               io.emit[data.to]('new msg',{ msg: mg });
	 	    //                     **************************


	 	  if(users.indexOf(data.to.trim()) != -1){
	 	  	 //                     **************************
	 	  	 //         THIS LINE IS USE FOR SEND THE MESSAGE TO PARTICULAR CLIENT WITH THE HELP OF STORE
	 	  	 ///        CLIENTS OBJECT IN SOCKETS_WITH_NAME ... I GET THE NAME USING EMIT VARIABLE WHICH IS USED
	 	  	 //             IN CLIENT SIDE SCRIPT 
	 	     sockets_with_name[data.to.trim()].emit('new msg',{ msg: mg });   
	 	     //                     **************************
	 	  }
	 	   else {
	 	   	   //      *********************************
	 	   	   //  THIS LINE IS USE FOR CURRENT CLIENT ....
	 	   	  client.emit("alert_msg",{name : data.to.trim()});
	 	   	  //      *********************************
	 	   }

	 });

	 client.on('new user',function(data){
	 	sockets_with_name[data.name.trim()] = client;
	 	users.push(data.name.trim());
	 	sockets.push(client);
	 });
});








